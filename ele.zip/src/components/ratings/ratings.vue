<template>
    <div>
        i am ratings
    </div>
</template>
<script>
export default {
    data(){
        return{
            
        }
    }
}
</script>
<style lang="stylus" rel='stylesheet/stylus'>

</style>
